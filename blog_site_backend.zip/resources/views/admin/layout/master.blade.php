@include('admin.layout.header')
@yield('content')
@include('admin.layout.footer')
