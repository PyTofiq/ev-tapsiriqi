<?php $__env->startSection('content'); ?>
<div class="container">

    <h2>Blogs table</h2>
    <table class="table table-hover">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Categories</th>
                <th scope="col">Author</th>
                <th scope="col">Image</th>
                <th scope="col">Actions</th>
            </tr>
            <tbody>
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($blog->title); ?></td>
                        <td>
                            <?php if($blog->categories): ?>
                            <?php $__currentLoopData = $blog->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($cat->name); ?>,
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($blog->authors->name); ?></td>
                        <td>          <img src="<?php if($blog->image): ?> <?php echo e(asset('uploads/blogs/'.$blog->image)); ?> <?php else: ?> <?php echo e(asset('uploads/default.png')); ?> <?php endif; ?>" alt="" width="100px" height="100px"></td>
                        <td>
                            <a href="<?php echo e(route('admin-blog-edit-page', $blog->id)); ?>" class="btn btn-outline-success">Edit</a>
                            <a href="<?php echo e(route('admin-blog-delete', $blog->id)); ?>" class="btn btn-outline-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </thead>
    </table>
</div>


<?php $__env->stopSection(); ?>


<?php if(session('success')): ?>
<script>
    alert('<?php echo e(session("success")); ?>')
</script>

<?php endif; ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Acer\Desktop\IBOXAPP\Internship\blog_site_backend\resources\views/admin/blogs/blogs.blade.php ENDPATH**/ ?>