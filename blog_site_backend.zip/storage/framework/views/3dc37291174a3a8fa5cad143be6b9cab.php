<?php $__env->startSection('content'); ?>

    <div class="container">


        
        <?php if($blog->image): ?>
        <div class="blog-image mb-5">
            <img src="<?php echo e(asset('uploads/blogs/'.$blog->image)); ?>" alt="" width="100px" height="100px">
        </div>
        <?php endif; ?>

        <div class="blog-title">
            <h1>Title</h1>
            <p><?php echo e($blog->title); ?></p>
        </div>

        <?php if($blog->categories): ?>
        <div class="blog-categories mt-5 mb-5">
            <h4>Categories</h4>
            <?php $__currentLoopData = $blog->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($category->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <div class="blog-text mt-5">
            <h4>Description</h4>
            <p><?php echo e($blog->description); ?></p>
        </div>



    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Acer\Desktop\IBOXAPP\Internship\blog_site_backend\resources\views/web/blog-details.blade.php ENDPATH**/ ?>