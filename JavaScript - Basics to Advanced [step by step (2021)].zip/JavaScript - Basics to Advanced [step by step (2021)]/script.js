console.clear();
///////////////////////// Variables
// var num1 = 1;
// var num2 = 2;
// var num3 = num1 + num2;
// console.log(num1);
// console.log(num3);

// Rules for JS vars

// Name can contain digits, letters, _ and $
// Name cannot start with digit, _ or $
// Names are case sensitive
// names cannot be reserved keywords

/////////////////////////////////

////////////////////////Numbers

// var num1 = 10; // integer
// var num2 = 10.9; // decimal number
// console.log(typeof(num1)); // number
// console.log(typeof(num2)); // // number

// // Basic operations are + - */ 

// var divByZero = 15 / 0; // Infinity;
// console.log(typeof(divByZero)); // number

// var multByString = 3 * 'A'; // NaN
// console.log(multByString); // number



//////////////////// Number Functions

// var num1 = 10;
// var num2 = 20.3;

// // toString() number --> string
// console.log(num1);
// console.log(num2);

// // parseInt() string numeral --> integer
// var strNum1 = "10";
// var strNum2 = "20.3";
// var strNum3 = "ABC";

// console.log(parseInt(strNum1)); // 10
// console.log(parseInt(strNum2)); // 20
// console.log(parseInt(strNum3)); // NaN


// // parseFloat() string numeral --> floating number

// console.log(parseFloat(strNum2)); // 20.3

// // toFixed() floating number --> round of to given position

// var strFloat = 87.34642;

// console.log(strFloat.toFixed()); // 87
// console.log(strFloat.toFixed(2)); // 87.35
// console.log(strFloat.toFixed(4)); // 87.3464



////////////////////////Strings


// var myFirstString = "I love JS";
// console.log(typeof(myFirstString)); // string
// var mySecondString = 'I love \'JavaScript\' too much';


/////////////////////////////// String Functions

// var str = "This is a string for JS function, JS";

// // Length of string
// console.log(str.length);

// // Find index of a string inside another string
// console.log(str.indexOf("JS"));
// console.log(str.indexOf("JavaScripts")); // -1

// // Find last index of a string inside another string
// console.log(str.lastIndexOf("JS"));

// //  Get a part of our string slice(start, end)
// console.log(str.slice(0,5)); // This
// console.log(str.slice(-10)); // nction, JS
// console.log(str.slice(10)); // string for JS function, JS


// // Get sub string function - substr(startPos, length)

// console.log(str.substr(0,4)); // This
// console.log(str.substr(23)); //  function, JS



/////////////////////////////// String Functions part 2


// var exapmleStr = "This is a JS tutorial";

// // toUpperCase() - string --> STRING

// console.log(exapmleStr.toUpperCase());

// // toLowerCase() - STRING --> string

// console.log(exapmleStr.toLowerCase());

// // concat() - It merges two or more strings

// var firstName = "Tofiq";
// var lastName = "Tahirov";
// console.log(firstName.concat(" ",lastName));
// console.log(firstName + " " + lastName);

// // trim() - It removes extra spaces
// var extraSpaces = "      myString    ";
// console.log(extraSpaces.trim());
// var extraSpaces2 = "      my String    ";
// console.log(extraSpaces2.trim());

// // charAt() - this takes a position as an arg
// // and returns the character at that position

// var charAtExample = "Test string";
// console.log(charAtExample.charAt(0)); // T

// // split() - splits our string on the basis of
// // the arguments passed

// var splitExampe = "Test String";
// console.log(splitExampe.split(" ")); // ["Test", "String"]


///////////////////////////////////// Null and Undefined Values

 
// UNDEFINED means var has been declared, but has not been initialized
// NULL is a value assigned to a var

// var myVar // holds no value
// console.log(myVar); // undefined

// var myVar2 = null; // holds the value null
// console.log(myVar2); // null


////////////////////////////////////// Conditional Statement: If-else

// if (7>5) {
//     console.log(true);
// }else if (5 == 7){
//     console.log(true);
// }else{
//     console.log(false);
// }

////////////////////////////////////// Conditional Statement: Switch

// var currentDay = "Mon"

// switch (currentDay) {
//     case "Mon":
//         console.log("Time is 6:00")
//         break;
//     case "Tue":
//         console.log("Time is 8:00")
//         break;
//     case "Fri":
//         console.log("Time is 10:00")
//         break;
//     default:
//         console.log("Tme is 12:00");
//         break;
// }


/////////////////////////////////////// Arifthmetic Operators

// +, -, *, /, ++, --. %

// var num1  = 10;
// console.log(num1);
// console.log(num1++);
// console.log(num1);

// console.log("--------------------");
// console.log(++num1);
// console.log(++num1);




/////////////////////////////////////// Assignment Operators

// =, +=, -= etc.




/////////////////////////////////////// Comparison and Logical Operators


// if (5 == 5) { // !=
//     console.log(true);
// }

// if (5 == "5") { // !=
//     console.log(true);
// }

// if (5 === "5") { // !==
//     console.log(true);
// }else{
//     console.log(false);
// }
// if (5 < 5) {
//     console.log(true);
// }
// if (5 > 5) {
//     console.log(true);
// }
// if (5 <= 5) {
//     console.log(true);
// }
// if (5 >= 5) {
//     console.log(true);
// }

// // logical operators && (AND), ||(OR), !(NO)

// if (5 <= 5 && 5==5) {
//     console.log(true);
// }

// if (5 <= 5 || 5==5) {
//     console.log(true);
// }

// // Ternary operator (expression) ? a : b

// 2 < 3 ? console.log(true) : console.log(false);




///////////////////////////////////////// Implicit Type Coercion

// var mStr = "Hello";
// var mNum = 5;
// var mSum = mStr + mNum;

// console.log(mSum);
// console.log(typeof(mSum)); // string; same for bool

// console.log(+"2"); // 2 BUT NOT "2"
// console.log(typeof(+'2')); // number


// console.log(+"apple"); 
// console.log(typeof(+'apple')); // NaN



///////////////////////////////////////// Explicit Type Coercion

// //To string
// var mNum = 15;
// console.log(typeof(String(mNum)));
// console.log(typeof(String(true)));
// console.log(typeof(String(-1212)));
// console.log(typeof(String(null)));
// console.log(typeof(String(undefined)));

// // To Number

// console.log(Number("2"),typeof(Number("2")));
// console.log(Number(true),typeof(Number(true)));
// console.log(Number(false),typeof(Number(false)));
// console.log(Number("string"),typeof(Number("string")));

// // To Boolean

// console.log(Boolean(true), typeof(Boolean(true)));
// console.log(Boolean(5), typeof(Boolean(5)));
// console.log(Boolean(0), typeof(Boolean(0)));
// console.log(Boolean("string"), typeof(Boolean("string")));
// console.log(Boolean(null), typeof(Boolean(null)));
// console.log(Boolean(undefined), typeof(Boolean(undefined)));


/////////////////////////////////////// Objects
// Object is a collection of key-value pairs
// Objects use keys to access data
// var mCars = {
//     'name': "Porshe",
//     'year': "2015",
// }

// console.log(mCars.name)


/////////////////////////////////////// Arrays Part1
// Arrays use position to access data

// var cFamily = ["C++","C#", "C", 'JS'];
// console.log(cFamily);
// console.log(cFamily[2]);

// // Update a value

// cFamily[3] = "Objective-C";
// console.log(cFamily);

// // Add more items
// cFamily[4] = 'C*';
// console.log(cFamily);

// // cFamily[10] = 'C--';
// // console.log(cFamily);

// cFamily[cFamily.length - 1] = 'C--';
// console.log(cFamily);

// cFamily.push('Ch');
// console.log(cFamily);


// // Delete a value

// var delEl = cFamily.pop() // delete last element
// console.log(cFamily);


/////////////////////////////////////// Arrays Part2

// var cFamily = ["C++","C#", "C", 'JS',"B"];
// console.log(cFamily);
// cFamily.splice(3,2,"C--","C*");
// // 1st tells where to start
// // 2nd tells how many items to be deleted
// // 3rd and 4th and so on tells what items to be added

// console.log(cFamily);


// // Delete item at specific position
// cFamily.splice(4,1);
// console.log(cFamily);

// // Concatenation
// var proLang = ["Python", "Java", "JS"]
// var allLangs = cFamily.concat(proLang);
// console.log(allLangs);


// // Sorting Ascending and Descending

// cFamily.sort();
// console.log(cFamily);
// cFamily.reverse();
// console.log(cFamily);




// ////////////////////////////////////// While loop
// var i = 3;
// while (5>i) {
//     console.log(true);
//     i++;
// }





// ////////////////////////////////////// For loop


// var cFamily = ["C++","C#", "C"];
// var position;
// for (position = 0; position < cFamily.length; position++) {
//     console.log("Position =>" + position + " Value => " + cFamily[position] );
// }

// var pos;

// // BREAK Keyword
// for(pos = 0; pos < cFamily.length; pos++){
//     if (pos >1) break;
//     console.log("Position =>" + pos + " Value => " + cFamily[pos] );
// }

// // CONTINUE Keyword

// var pos;
// for (pos = 0; pos < cFamily.length; pos++){
//     if(pos%2==0) continue;
//     console.log("Position =>" + pos + " Value => " + cFamily[pos] );

// }



// /////////////////////////////////// Functions


// function mySum(){
//     var num1 = 10;
//     var num2 = 20;
//     var sum = num1 + num2;
//     // console.log(sum);
//     return sum;
// }

// // mySum();

// console.log(mySum());


// //////////////////////////////// Function Arguments


// function greetings(name) {
    
//     console.log("Welcome "+ name)
// };

// greetings("Tofiq");


// function totalSum(num1,num2, num3=30) {
    
//     console.log("num1 ==> " + num1);
//     console.log("num2 ==> " + num2);
//     console.log("num3 ==> " + num3);

//     if (num3 !== undefined) {
//         console.log(num1 + num2 + num3);
//     }else{
//     console.log(num1 + num2);
//     }

// }
// totalSum(1,2);


/////////////////////////////////// Scope and Enciroment


// var num1 = 10;

// function sumNum(num2) {
//     var total = num1 + num2;
//     console.log(total);

// }

// sumNum(20);
// sumNum(50);


//////////////////////////////////// Variable Hoisting

// num1 = 10;
// console.log(num1);
// var num1;



//////////////////////////////////// Function Hoisting



// sum(10,15); if it's not here below one works

// var total = 10;
// var sum = function (num1,num2) {
//     console.log(total);
//     total = num1+num2;
//     var total;
//     console.log(total);
// }

// sum(1,2);








//////////////////////////////////// Select HTML Elements



// console.log(document.getElementById("topbar"));

// console.log(document.getElementsByClassName("menu-item"));

// console.log(document.getElementsByTagName("span"));



//////////////////////////////////// Query Selectors


// console.log(document.querySelectorAll(".blog-card"));
// console.log(document.querySelector(".blog-card"));


//////////////////////////////////// Update HTML elements


// var countdownElement = document.getElementById("countdown");

// var initialCountdownVal =  countdownElement.innerHTML;
// var bgImageElement = document.getElementById("bg-image");

// setInterval(function() {
//     initialCountdownVal > 0 ? initialCountdownVal -=1 : 0;
//     countdownElement.innerHTML = initialCountdownVal;
//     var backImgPath = initialCountdownVal % 2 === 0  ? "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFRgWFRUZGRgaGBgaGhoaGB4ZGhkZGRgaGhkaHBocIS8lHR4rIxwYJjgnKy8xNTU3HCQ7QDs0Py40NTEBDAwMEA8QGBERGDQhGiExNDQ0MTE0NDQ0NDQ0NDQxNDExNDQ0NDQ0NDQxMTQxNDQ0MTQ0MTQ0MTQxNDQxNDQ0NP/AABEIAJoBRwMBIgACEQEDEQH/xAAbAAADAQEBAQEAAAAAAAAAAAAAAQIDBAYFB//EADkQAAEDAwMCAwYFBAEEAwAAAAEAAhESITEDQVEiYTJxgQRCUpGh8BOxwdHxFGJy4YIjM0OiBVOS/8QAGgEAAwEBAQEAAAAAAAAAAAAAAAECAwUEBv/EABsRAQEBAQEBAQEAAAAAAAAAAAABEQISIVEx/9oADAMBAAIRAxEAPwD8v9f/AGO3Ejm/ogkc2gz1DHvAW3NwrB9O1eO0EcEhUPXbdvJZ+wHzXYYM5vkTOahFQFneQC0Ye/fxt84uMzJ9Qpg98ct911vvdbtB5O+7Du7nzP3CIVDfP5uZx2BP0VO7577bb7SRwLK2ibA5kQCPi4YP2UPdM8b4tNz2mDyT0q7ciWRO8xxsdyO5vUOkeqg2tgcet7C/SZzwqO5zmdha5FRucBwjlSxh2v5CBwDUbwQCsrVA8G197CYnwi5BED1QATAGblvn7zadrznhDe3Fw25pzdx3HSEyBBqNph0XAOA4X6ibo0JIEYlsn/JptbvsJIj1Q4HgPHIzk8XEnlaFpkxZ+83D+/BP0gcrKGzux3eYHf4hZFoZQ07kY7iIubd/zR1RmRT50g7dsK3yPEAcX/42FQ4EWUFu7Tj5iIMkYAlQaaZxY2gbfMqZnPnJO3CpwBE/PJn+7EBE3DsTvFuLDdKmz2m2ebn0VEXcIItMZ7iUosYAyL7/AMKnQC7xC0R33BSBA4vsRcfc+ak428PH3dVVw42bAtufd/2g+Ziw2FheEKKL+vw9rqY/IcKifX5nP6hTx58cKaEH7xykfu6YGPXZJRTL7ypKpJyiqSgoQVICRTSKQCRTSKVBFCChSCQhCQCEIUmEIQgBCEID74E7kzbxtObe8P7vr2SIsc4J9zhrvv8Albhp4J3uGHBnPp+alzdjaxF6B7pG3l9yu3Y8usnDM/3/AAbgH7+i2kTkb7s3Lhs3y+4Tpmb5kxLZ6tMHZvaP93WocdpJyIL74eIpaM9Q9Ce6U+FalzSbX+pHzNLbVNWLjJtcyIAFZmenENF7Y97daOaNoOI6HuJsQzxH3mm3+AQ8VZOo4cNbQCC5rePeA+YU9dHK53QMkDGTW4QbWsARTBHBSLDF2kCDd5jgEBvYkm3yXU3QePDphgsKnkTdzmSS8xGWm2RssX0jqLi92/wgwMk3dBEHY8rK0I72IByRSwOuYjeoNFrJ+Rm1pMFzLgtPV0xBtkytnabqocOuDSwA9Deo3AuCBcC9k43qOQauqzptqXAs7EE2uUaNc7miBN2EmHe83emJj0n3pUvkAVAPbFnbi53znnhbwZJaAH+8yxa4ctHvDBi/MwsrRLPDHUyZIsR6iI6tpRpsCKcGppt6SJkXpJhS4RDhg7XjIJb3GFsRFx4HZmYB4yKi0GZWbmRIPEiQZ5EcEiEtUzph0ZB82gg/pP5JM22vnPGGqnYab5iSZFsADYAFSDfI8RxbnB2CQIDEjcmR4o/TlSHWio3N7THfuq2/4jFsnfn0Q4wcmzYFudvqUjFRM3JmSdpAwQVmfni/c8903fkB34xwk7PncItMEyfMn77qOO2UO/nz9Uj/ADj6KDBG3ql+SZH+v9pE/VTTJIplIqaokimkVICRTSKQCRTSKVBFCChSCQhCQCEIUmEIQgBCEID05ZHuxnLNMbcz3TadwcXs7h0nwNtZx+R7BaBoGwByAAxpJF4gS6cfNJ9843mTIpg+JwmWUkWvZd3p5ITWkZqsP7//ABuh2Y90+gtaUDTItBJBpHS6S9t2gQ+Zc034CdImTSY6iYaR0iHmb2I/9plT+GADPSA1oJpBcN2NaIBr+LssuqBWBJBxEQ97SXO8AAd8BMK3aREiNWzmM6XBwrBl4HJ3aBurAeHBob1i7GAgs0ifEHB8jqFxfJ9FOi1gLS27NMFxcHHTe9xggNqkFzCdtlnaHNqfhe8dUnryG5q6RJO4me6109cTGhpkHqIcet4AMgi0NIbIJ3C3Y5zQxrtV7CWarzWwloDwRLck1gZ2lFbnAB3tLACNMkCqxLfw4IaLlrRBHB3UXofWP9NTLJBfc6jx1DTY0dUbkiCSWmCDAVBk3DZF4bDiKR/45fg09TYBPWMJ6TGEUt8Fnaj3AYEGlrSdjPhMkHsuk6JPiFBJAJIdLTIDbvJMMNLNhBEpaNfP1WCACem9D8QPhdE/K5xeJUapMlxEPb4wYh17ze5kjpAiAup5gElvS51Go3ZjxIDxAMbmOzhusXtc0kdQfpkQaXB1GBIwwCZk360aJXMWCbDpeLWBcCIwAbS6R5FZyRB8Ja6k36vOk8YW7mAmlvvAPa1pDiHRZpcYMgTPosXEbQA4XA6iC3GcSboXGL2QHWwRmzoOOn5JONzBm4NhA49Fo5t7j+0lxkhxGeRtysnX72i9gIx52Rppdx2/IpOvPcSEyfXe1goNvMH780tMp37QUjx8inEev2FP3/pTTI/VKfv9Uz+SU/cpaZE/fKRQUFIyQUJKaAkU0ipUEimkUgEimkUqCKEFCkEhCEgEIQpMIQhACEIQHrmYsbXxFrST0QJph1z7hTiOLQbeHMtu2JYXQQQTTSqFyAMkw2dneNhEjBkts1DBJbHSXTQ7djxZ2mexvEkZld/qPFopEwZiATgksYZJBw6p+7TMDCpjqYcctc97t51XiGM7FoEmQIg9lFQprp6KqdRgyx9wHMxG8CTC0exzS8T1sbWx4kF+mZqDjaZDiS4yTBCw6GqZpCKCC4WBANJ1dVzqnVO+BsZFpbYyVb9MEC4cBJY0QzSqFqgHdWp4WgmOobzmA0Ew0dJax7QCOlr3Br9MAPkMJcekSTaV06bTcTeaDEguIqAaQIIMNtpjEuJJwsaeuZ2k4B8GC8EOeDRphkFztNjX+IFrWlpEcBNzZM9FJopL9IgjRYbarqJABIpduZW4GYIBIBDsEmrTcxwcImDUbbTcgLc6bCXYgnXGATD3lrR/cRS58HeAs6TiYHGAcgghgZQxjw4+JpEvLS5oiDIdBK19o0w1joGWxtJLnsa3a5iNpkLrL2iTYZcb8AFxwZ6WC/ab78Xtb70uMf8AU02mprw3pBc6p0wRU82MnEWSE+sfb2SfahBgarT4HWNTxJJgMO0FsnFlzalJ1G3ZD2NB8ekwFzY6ibmHCScEhaEVD2ggNioOBDy1oFbvAw+OZtOAJWOvU7TY/rcGdDnOhzGmamMZvEXIKUqo5gC9haKiWVOERSGe+ecwoc7ceFxl7GAikNda5nOZmy29puRqDrBhz4ZQxj3O8Ei0EDssdRpyw+KouYwO6Gz4Xcjf0uqioyNqSSBNRq8TtxBE/cysy2wke6PEbQLW5H7LV7gKnNhoPTTMmC2+RcHnN1m5vAhpsC7ANpPH+k1Rm6/fsLBR/qw4yrJnv2FgJUuP8D90qbM/f7IPfP6IP8hSlTBUplIpGRQU5UlIwkUIKigJFNIpKCRTSKQCRTSKVBFCChSCQhCQCEIUmEIQgBCEID1xaQCBmkx/npOkeZpPdXrNqGo1vvMbrs7ERWMefGAlp6gBDjeHscZ+F7aHY8ufRVoCk6YPuPfpO/xfNP5r6Dp4Y0HU5x/+72cuP+bRJ35B33RpOB/DcSJ/ptQG7fdrAuQ6+3PCn2IGdEbtfraR3yOkYP5J6YP4bbm3s2oPe3eQfTPZY9QY30GAhjfF0aDYhmoMu1HAsEPwLht7EErbSMhtgZpbY1COlxYCR4eu7DAx1qPanQX1Xhz7OIddmgGt8Ya7B58huq1jDiZ8JMzMww6MAlwqIjAeHdmrHqCQVzvE2N4s4RN3NJ8bTJBmndrVow1XMSTJAId1XqxWfFX8xysX2s4EC4dE3AJ09SRU28FjoiSBJpCYe7fMmokktqFnHxOBmA/FwdQi0LOw0e1EgOBwLHEAgts4EkHJ6W9d7lceo4tAcJFOs68gMmzm06Ju3EyewXb7TBs6xiLgSGmRArpazcdLPLZcftGk4B7ouWGSQXl0Pqc4vcAGODQPDM0kWkqLFSJ1IZqkmCzUqpfqafuPd/3AwYIvELmcKASWVscHt03ODg0kGPxG4uLZ5W2qafxqaSAGtAd/1HBrjMse0UtIPl4oCl7KH+GzGVFms6xJAqpAzJcCB2BKeHGDhQ40k6mm0sLrPaxxiwdwcj5rnfLQHNcBWHAtabtbMFruxGOYWjfCA1znVGXsaCPAbdnGJ8lLjFT2M6HFzG1Q6MHPxAEXRiozc6l1TAQ0yAXwciHXiJEnyWL2BtQJkgwIu083Wuo2Ja580yW0mppcYmDtbfsswZs1uWkGYMnJInCDQ852Em297gcwpcPvbsrB3knHVuJtEHP+lm7/AFwimhSqP2VJSMikmUlJkUimUkjJBQgqaAkU0ikoJFNIpAJFNIpUEUIKFIJCEJAIQhSYQhCAEIQgPWFwI/tIIP8Ag8yCP8Xz5Sh0mQbFwDXHZuozwO46gM23UVHi8m393vsvYhwgjN+ENI2uKZjd2nvi8tg8Wb3Xf6rySOgapMu3Lm6gHD2T+Iy85Enb9Fq1rcQKets28Gr1NcOmel2dxmwXM05m8AOPLmAyNS3vNy4TckDZbNOZIw50gSIPieAAZERW2bmyinjqD9yI95wF/c/D1AACOzxsRNym3ggG3UBgiih9IEWcwNe0iAafEVGnmIvIt0zIbLL8x1NebM8OSt2sEci2JFvFYGbkAvaLuBa4dIKm86Jyxbbgm1pADumkzgUajd7NqEEuKQIySYgGpxqNIPS9zSJJaehwy4RENXSdPM4klwFrWGoREjDm6giSINwsyxw2lwrdEHqezp1G2+NhDje5Hi2WXXK/LIOpxaIBa0y6RT0AtIqPwGIeXR7oWWo7JgYmqLSA1tTZaDH4gDc2NQO5W50vdBLgWiI8T9E3ZqNJy9hta8WEZTZ7K4mbTINQsC6AA9s3a4gtBY4AXtGVF5GOPXcCHAEnpe0C5gB4/CGTIqqDbxAsVjr6Y6w0RW5rB0iOgAvPhkQYkiIm4OV3u9jEZG4A2x1NA+HsJLZsRdcur7PE72AMEAkCaWzHT7okZkgyBKXkY4tV8kuDnZGnpmtoNI6eqI6YtIgLncxok0yAKTLx4yD1AjIkTxbK69Vp5izhMWa3rs1gmAbkzcZXO9lzDRaQGkAkDqkvII6tx5dk8GMjLfdbLDJMgkybCJh3pys3nYuqAdgEwZuS044237KiBaKSBMEtcKgZlx8v03UnztdpgRImxJOb79ksPGbm7EctxEEYvicrN38hWeI8xj1CzcpppKlUpUgihBQpMikmUkGSChBUUBIppFJQSKaRSASKaRSoIoQUKQSEISAQhCkwhCEAIQhAelHYz4RInzY63/5uRlNhJgNF5Ja3IDxZ7KR0gOg52Clw5xBsODkNnmZb3J4SeQQajb3iJcBFhqAAAcN+a73UeeN2EEtpMCQdMmDQ+fA6elrSZPotdM9oIM03JYZ6XsqmpjjU5waMDdc9ySIl/vsMEOtd7B4WkNAF+VrpPBwXEC4vGrpyDIvd7QwHgdSk5Hfo7DNpEEkUu6pz4HEVmwh1AX0NJnnPfqOZJM7yCTyQ+TSvlab7dpJlo6ZN3Oa0jp3lkXokFdbNYC0N/wAagZJLWtaTVeTS0mLhh5KqWNJy7Dp/2g4sTZwMtAuPCWlzATaWiBF0xomCZNgHVSWuqY2Gagdlr6aWuBBBkXuk72prWvd4qWamp3cGPGnJj43m5HuMgcrn/wDlPbh1srLWOGg7S1gJDgwVvDoFiXmogCxa0RACz76k/kaTh1e0vZpNeY6G67NN4aLMc6XPdR4WkNAFgOrpxK+d7Z/8i5rjESzUOoyDbU0nChlO9hcCPiOy4PaPaXOe95AZqPgalJB03l5JNRmGWN75k2XKdUDBLep7qdPLHAUiHm7mkd8LG0eHS3WIhocf+2/Ta4SOkmprwXAUtdcTudkf1UCqCGN0muYxpLA5xIY5ziAC8zVPMBcvajUAJaDDpsG1BsERnqHAUHUvJIkgucaYcapa5jdsGRYZS1N5dT9SqGky4tqMQGtBaTdznG4BvG/K59RoMkYvzSLn094H0WTicReigi+BBZJJgWDbdlDtTBzTpim2DgnGUek3kPG/O/z32FxYBZOH3+l9uytzzzwJzO5lYOelcLCefv8AlZFUVJWdIlKZSSMkISKQBSKChSZIKEFTQEimkUgEimkUlBIppFKgihBQpBIQhIBCEKTCEIQAhCEB6Qn84tcl24Z8TsdW22Lpzo4sY5bJ8LLmC3c91gNa3TYlga0jIg9QHcrcuB8EZDGNGwcLvJ3M27Su7etYSE2/TFQHTTUK2R1Pc2LEG8SThaDVk9TgcHrljxURh4F+loEm18LmebEZAIY2ROD1Fsnpmx3yr/EzBgVPHiMDopGfM/OMLO3GnMdg1b3k4JxJ6mgzTY3c/qsROU9L2k2IkuB03ATNTmPJcIrNyTa3yXA7Uk3tJ4FpioHkZ+ipj9+znxc+EEMnmOdpUXprHcPaIppJ6Kw1wFXRdzmPYYMSQ28ZJXMX9LqZEsEhhqZ1OBdV8OQIG4CybekR7jhvy8+6ATfmc54QvTYmWRAFOJjA6haTyovTSNNV46gYippoYegiL3mxgx6nhDa/dAYKnCbNIrE0udkiOe6zDjFg0At7XpuTJw4kdlDhNy6TAOSSZ2nkbqQ0aDYnUA8OXOtMtOBsBfsd8KC4/EDZlj2JhtxgZPmpcxvxfF7pvHhPkfok8N5cc7AcRv5/RCLAcY5NjaxNNsACfkVm49+RxnYA2ABn5pOLdp+nP7KS7uf5yhFMu38v25WZQfuykqbSIqU0ipTSKlMpFFIFIppFIApJpJUyQUIKigJFNIpAJFNIpKCRTSKVBFCChSCQhCQCEIUmEIQgBCEID6Yd8vXpP6n6XTrPruL3tntt8ln8r+kIn9jfK6usmx1dpsL+ZsLcFH4hJyL/ACyTe11nPmNx80TO+bz3StXGlVu3nfA+mCqJ5/5Wxf8AlZT2/lMH78vL0U1crX8Te3GNoN+x3TnyIHfMzfPlgLOSe5Ij5BAI+n1SVK0iMg2z57JSO8x9d/RTPfv98oLj+t75QrVEt75+m3qpJHfZTKVXYfYQm0i7gfr94+qTiglSUIoJUKipKmppKU5SKkqSRTSKEhIppFIwkmUlNMkFCCpoCRTSKQCRTSKSgktm6DjcCxn6ZQ7QdwcT6FLKGBQt/wCmffpNrn7+aX9O74TmPXhTl/AxQtXaDhkbx68IPszpik5j1Sy/h/GSS2Gg4+6d/plA9nf8JxPoll/B8YoWw9nd8JUv0yMiJRlDNCEJB3hBKkqiunWRg4+whJAQqKB4Tn81Lv2QP1H5oUqVQd8tlmU+EGsFCg7IUhVSRcmP1SKAklJNykp0iKRTKRU0qSSe6SmpJIpoSBJFNIpUApJpKTJBQgpUBIppFSAkU0ikpq3WIEDgj5xP5Jn2l175z3sRf5lYoU20mzva3GZOf9/uUf1Tud5+/kudCXqm2d7Q4/OfW37BV/WP53nC5kJbQ6W+1uEQcTAi17lL+rfzgQudCXqh0D2t3O0LPU1i6J2WaEaYQhCQf//Z" : 
//     "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExIWFRUWGBcWFhcXFxoeGRYfGRgYGBsXFxkeHSkgGRomGxcWITEiJSktLi4uGCAzODMsNygtLisBCgoKDg0OGxAQGysmICUvLS8tMS0vLS0vMTIvLS0tLTAyLi4tLjAvLy4vKy0tLS0tLSstKy8tLS0tLS0tLS0rL//AABEIAOkA2AMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAABAIDBQEGB//EADsQAAIBAwMDAwIDBgQGAwEAAAECEQADEgQhMQUiQRNRYTJxBkKBFCORobHBM1Lh8BUkYnLR8UNTohb/xAAZAQACAwEAAAAAAAAAAAAAAAAABAECAwX/xAAxEQABAwMDAgUEAgICAwAAAAABAAIRAyExQVFhEnETgZGh8AQiscHR4TLxFEJSkqL/2gAMAwEAAhEDEQA/APi9FFFUV0UUUUIRRRRQhFFFcoQu0V2K7jUKwaSoV2Ke6fr3sm4Uxl0a22Sg9rRMTwdhSoWqy6SCLaf60V/DEKKLXCtM2Uqt13qZur+FZT0Whe62NtcmhmiQNlEk7keBS0VZjRjRJnj58wFU01XFFTiuEVKqWKNFdIrlSqEIooooUIooooQiiiihCKKKKEIiigGrAJqFYCcKuipMlRqVBEIoqzT2WdlRFLMxAUDkk8AU70/TquoVL9t2CsRctqYfaZEkiCD8+Ko94aDuBMDMdvZWYwuNuyRt2ySAASTsABJPwB5NGNM5lLha3kmLkoZ7lg7CR+YCKrZiSSTJO5J5JPkmiSTx7/PPfudWsVeNN6/UXLlwvdYs7BSSYkjEY8bfTFaum6TYuX7Vm3qTFy2CXZIAuEH93EjbYb/Mb0h1DRejduWmIYoSsqdiffj+VYMrU3vAH+UaggwTGoxIuNbJjwiBwo2AjsA8oMYlAN2gwTkQIJiTP8aru3CGkQpXaU242kEf1rQfolwXFskRdxLsrFQoGOQh8oJInbaKX6Zf9K6lzBXxM4sO0/f/AHyKOtjgSwh1pA3mY8nREmy26Dr8/wBJi3csnT4iyVvZT6gY44xEYzzO/wDfxVHV7wuXZWytrZVwSYkbT9zWlZPq5BbAze4XHp5dog/u1QbYjmfii5olNtHRIa20XCSSHkypj8uwI+awY5odLgQZOTMT5xBIgc7CVuaJcyyTs9GZ7V65K2zYAzRyQ7Ek8LG3tHvS3StO73MURXYhu1hO0SY9jA5HFaGr05uObhABYzt/vnzVH7OyHJSVYcFSQRsQdxvwau1zi0hxucWsLDzImVU/TkEGFmFCzbD6jsB8nYD+lXdQ6c9m56TgF9pCkNufy7fm8RV2m0ubrbNxUB2DXGhFG539hP8AWlSCrbHcHYg+x5B/nNbhxLoBwLiN8GfI2/Gqzqe64uiuEOQjRb/xNvo3x7h432pUinUILg3GbFmHqEbsQTLHfluTv5qfU7doXG9Bma3JxyHcBt9W3vP6VLXnq6XbTYGNLTvMxiyydTtKziK5TNqyGyl1XFSwynuiO1YB7jO07bc1QVrTqEkJZzFGiuGu1ZZooqzT2S7BBEsYEkAfqSQB+tVii0whFFFFCEV1GrlFCkJhd649mqrb0/aM1mbJimA9KW2ZCGUlWBkEGCCPIPg1fpWuG6CpJuO0Ancsz7bk+STyfer2sVU+lYANicSYBjaR4BqpcCNNr/PZbCiWmys1GnuJlackMtwg2pJ7ogttIJ2AnztVd/TMjFHUqw5VhBHncfaooSDMkEGZneeZn3rSvs7Pnd73ZQzFmBnJe07Hbtx28RVepzSAYx72wNu83IErZlMHCzkX3E/Hv8U7qQjs7ogtLIi3kTH2J3Pv+tXaK0iuvqWnuCciqtGSwZ4E8gGZ4B+4YbSBrRuBVQBj9TybmTABbaxPYOd+N6zdUHV+9L+fG1vVMspbpHU6N7bYXEZGABKuCCAQCNj8EUz0/pV26Ha3bLqg7zICpKsQWYkAfS0DzEeat1ncFuG4z3D9eZYsMQACSeREAb8CnNHaW3cuW7gIBQqFYiMyowZ4IEAsTPiao+sQwnK2FI4tKOgZJLoXDgdrKeJ5y24xn9YphdPMD/Znff3p3pGqe3AXHsIUwqxcxcsM4/xBJiTyIHFa1uyRfb1QqMwZgCqFZeYETCDfY/lge1JVKoDybXxuY8uffmB0KVMQAQs/T9JYjYUnrOn48ivqHQLVoJkykj6QeQWjifNec/FARSVWCWHdkkMkNICk+4jf2MUlR+re6p0x/PzZSysKlQ0+nGvz5ovF6npDjT3r1pgEMI1vZnIJX423I9jFJam7ZBe2npXFeyApNoqyXCBKjf6p2y4/ux1QbySS+3dJkRtE+4gcfFZ164pAJzF0FiXmQRj2gDmZ2J+Zrosplw+4zfSBtE6mIzYmcHROtTh1lUmitpZuteS6LhIWyVjCRBYMfsRWbplQuBcJCeSvP6frFavS7dhnjUtcCQx7BJygR7/08Cq7q5CcEWSzHERyZgjwBwB7U017g5zTN9cASIgeknk8pI0ZNvndJ3bhw9MR6auzrKjLfbdongDauWL9pbd1XtZuwUW3yI9MgmTHmdv4Vy+Ype9bKkhgQRyCII+4NbBrS3p88xrOnvv5pao3p+fPJLEVGr2tmJgxMTG0+0+9UkVukXsQFnx8muUUVKyRRRRQhFFFaX/Cf+V/afVt/wCJ6fpz3/eP5x7b1R9RrI6jkwO5VmtLpjS6zlFX2HjmqhTFwLC4zMd0+/x8UHZMUm6rT0TIfqn4iPfzPxNPnTFrLH1RgjjG2T3En8wX2j+9YFl4rb09wbYjIdv1DkjldvG/9KUqsIMjf527rq0CHCCklsEMCORuu07gzx5qOPdJ8mTsP124r0Om1LhLiJAFyMoG4xMiDyOaot9OUpcb1MWQKVXH6pcKQGnYgHLjxVRVMnqHz5omf+PF1bp9Fpitxzecwn7sKkMzlQYcExgDkpIMnkUaLTbJbe00uMk2HcW+giSO0kRP9acTS2jprmouX51L3AQkiWBeHZgRJ/MZHx81s9N0WruvYcgkWbSmzMKAinICRBP9aSq14aT1RBObXA0xIGp7ram2LzwZ7aW9fVedvWbAS4Q7O+WCicQF7TMHdoIK4/r4rU0ujsjRjFkTUhrrFzcKuqFCnpFDt3ST9pr0146W7ca2QlmxcUEMlsA22xUYH3HnKI+dqzOm9ItLdsmVvoxZmt3BgGH0yIklhuYO3bWBrmIeS2+t7QbGwA5Bg6YkKxaYlwIOYjvbQadtVn9P0LWwPUUKclBViciCMvpBmNtz7xW10W9pxfJuKQokKwWVJJhcwxOA4jetLV6Frjemhe5G+Ha7AiBu4VQBidjvxvyKLGn0ltWtlk9QdjF+5Bkry6ArJKkRBHMcVjUrdbLgnqz0473Pb1srveHU4vOw23/vHfRc6/0nCBkKnJ0Zd85uZKlzyDAiRvuPE1l9d1pu5O+CurSAZzYNHxBRAogbGG807r9Cqqz2HRktKGZlbvViDEkjfg7VToOmIwu3rtplW2isuTTncMxM7emT9R/LsZUTUUA0HqIv5A7xnUZifIBT4jGjr198jTnXObaLG6r+Hn9N7toM9tST6uyoy4g/u0buyBzBnbtjmRXm9boCpTdDmquMGygNwrezjyvivQdOK3GZbjMtt8iFBJWRuFaN2ESIEbmZ5qy70dAxBcK6oc4hle4OEQoIEiPgEGa6DKxY7pd+OPfGmDG6qabi6HH2+Y1ssvp3Q2K3mZYFlWLAjfIiAseI5/T5rKvwonnfcb/HPwfvO1b/AFbUEue/PtUFlUrlCg9w+CSCT7TSVrpXrLcuBjbtJbLywJDlZEbH3nf+VWbVLPvqnMaG3HM5x7CVnUZDVnroxfW85uW7CKGe2h4ciZRCTJiQPP1DasnVW3LFnLEkBsnmWDcN3bkH3qx7R2Mc8fMf+6tu3wbQtvbEiSrx3n8oVmPKCDsPam2hzHSLjEagWm+TiTMnXSVzqjJyqrfUnFhrLAPa3KA8W3P51I/NGWx9z81lkVq6CxfvRprUsHbIJIALKp7t/ZZpU6WNjyNjWrOhjnARJM251I0Jg4zGUk+m5wSJFASmnIFKu1bgylHsDUGu1GipWcooUUVNaCrNElNnWMbS2SFxVi4OIylhBluSPj/Siyi4sSxDCMBjIbfeTPbA3+agLXjg+xpl7ZaAqAQI28x5rL7W2Ai5JxnJ9U9TYSqEWtXp4IBdLkXEZSqgNMby4YDFQpCjcz3fFVi26W1AdSLpnBSGYFSAMhEqTO3vTlrTFHK3exh24Yy0jGAd5UH3FYPqNIiQffBg2juDEjlPUWXC+g3dbbdX/ZrP1IFZwgU9wIAxgloMfz45rFTp4w2cKx7WVgRtPEzuDsTttFej/Cd4CxdZ0UBAD3HFzE5C1PLAKSR8/NHUw9y61tO5ZL9gmCVA7m9jJ2/9DgU3eC4sAt/5Eg4jOk8WGy6jIa7pHrPb+eEp0bpmTrbTG2FDsbzr6i3CkNioYQo+PIbcTtTv4b1ptm4jg4srJ2qGdVEwFMgAd2+3gbU3ptKyqPTcuR2lFVgV3URkBsS2wP6VF0ZHKel3OOw+UDGdvcxtQ9/UCCM/1JM/3YRtJAd1Tg+Rtrfv2t9tlp3LdgafdFJA3TE8xAcnkbxMEVjdDLS9p3FoKJ9QjvSQQFEiCPv9p3raBZ1tNcVIUsgBLKW4hrhUzzERwal0nUaW6cDacuVWXI4KkJ2nwAPPmSKwDehpaTzJ0jvmb8G0hLl3TTfIJvJiDF+eLm2wMrMt3biupVsVVXRbiRm4RgSzFT3HzBMECq+taMtcsKqXVtM4Ny4FPe5/xHUg7yq5Rt9PG1eja13rm+ak3mxOMLLErJhfqxyM+Yiq+qWglsBQbglAhTZbZZcFYiTnPdMAmDG1a+J91sfyPLH+xCB9QOpoAEme15GbX1vY/wDXReS6YhC3HxF7Tjm2p24cobhG4KwCQJ5/izd6NbvaFGFwWyATiWAWVA3PPeygkTv4NbnTOi37JNkojBu+VY4AnJVLAie2BxJG3vXP2NFRtPdiwAvqH0t1YgwSx3IBJ+kDaQJq5Di/qjBF52zr6zEzEqz/AKppf9jtQZBmRj/HU8xJEDReY0ti2os3Bcj02JKQxVfLEEmQXie3gg/FN9c6OGt3LltgTDXLiNuxH1eopbjeZ3nenOp9PtItp7YC5DOGcbAD6Y+5HxyDSB159dSlq+Uuhs8QksHUhQgwxXcTv4H8M2VS94LTvkiPO99dT+1tJd99Mm05jQ4/N8zHJSHVrendUC/8uFm1ddWlHLKssWmYIA2JHPnmvI2rq2DfT6nabSmBgVyIZmB33AERxXrb129aUB/QZXBQ2z9QH0sr+nv+QqCSTDT5NJucLB0/ogG44cSQSMz2geZ2jc03TMS03BIkSBgyTMSYORbyVRTMRpvPrnbz72Xn9RoQ/wCz+mot3WyNzsZFSbkW3LEkMmO8gQB70nrdCiNcVmzuB4zVgUaJDEbbgmIPtWv1u5dQI1xjDLFuSJKidiBx42J8+d6x31EWHAuLNxlVrZSWCp3B1c/T3bQOaeokwDOuknXeJjS9uywqNAGZ+fwlW1aKGhBkSCpE9sHcAzIHikNbbcBWIhXGSexEkbe0EEb+1MpqHySFD4AgArIjcmQOeSaRa6ccdonLjf8Aj7U5TaQbeev+tD5lc+sZsUqwqDVcwqo0wubUao0URRVkugVodI6e9+5hbKqwBeXbEdu/PvSC1Nao/qLSGmDoc+39rakBN05rNZcvObtxiztEtAEwABsAANgKuS8oRYDZy2RJGJG2OIiQeZn4pRHrRGICgXA2ahnUSMSCe1p2Yjn9ayPS2ABA0AxjjSMcwuhSBmZTdu7bgqe4nGHEgDyRBEn23jjzWpptA6ldRH0G3cljzJyQneSDFU6PR2LthYbG8GICwYuL9WbMTEjdYAGwnzUregcWw0MEZjiY2y4MfMD+XxSb3AmJ4M6+4FwDj2ghdWiJyAV7Pptn/nHvXe1Lim6hf92qsxAYWwQwIEFa7p9U1u9uty2JBCx3LCwJBgEmB+hHNL9N1tt7Vq1cD21STcuBss33x7cSV2n+H61voyXLQuEszKxliwzMKQslt42Ux4ExXGqw09Lxs3ji+PK8St2gM/yBg2/jjv5GLrc/DujRpYFT/wBRG+X1zHnf+lN61xmJYlgoRYBBWfMx+lZPSpWyGQNmxiSeFjcgDxn/AErUcXGQFsCVm5yQWWNuJhYmRyRIHNIlsvI3MEz7EYsbc8LnVmnxiS60xz80UL+hUuk8McQSMl7cizcTHEfrJpe5obVu6GS2wRBLMXxZg2wABglfqMAxxtWs+qYmVugp4VB+gAPkEVHWL6yKrIUKyZj6SNgE9zFa9VOCwabj2ta3vzlYsrPBHVjBubeVjMWGYN8qu3qVe6BbtiAMCSoA2aZU8/25qz9mtqzZqtrMZSO3LAzIUPtEiYg933NNuAzz3AxiJGwImYIMzJFRCTkCATxLLMz4mfI8+Ks2Q8tdfGwwCRItri4vqlzU2kCBrfPve+Fk/s7FpD9xaS4cs+BPam/AkAmZ52MACqerqgBzE57A25Y5CWxggTP7vzypreFlGTCCOF7NsdoEnyIFJ38QwmcmdF9Uj6cQfp9to38z8bQD1Q8xi2Nv6ycSQUxS+oJffT5M353xtJXn7nTma1nhbS0DmM8nYBlZZB/UbREgb03rNXbQOV/cN+zbjA4HI7IFMBC3j7GtDqGjVgyp6ZUj1FcmT2MCVT/p5BAPvxNZl05Xrnqsty2JUW7juZKRO5AIx53BnPzE1qQGf5HBn8mxAM2vm/ayaZU8USZMSY9LXJk5mToZiL4H7VkpSEa49uEKKCBOJZXdu5X7RHJGRgisH8Xae9ZupdFv0WhSRlk2YALOe5pBY7GdxEgTXqOv6W4ES36qfs6kKSGJUl2LxAktipG8TArM1H4bbPK1cUt2tbCXAWWFZpnYjELM8jt96YonoN+176AEH23wSbkp5vSfvkAGd/cniJBBheHvatyhUhDlMsUGW75k5e+U/wA6rGi0/oybzC8fyYwq/ckHLaeCOR7b+ov6KEbToMnMHJCCGAAYqxPgQSI4O29YV/ph7YZWyxjFpgsJxb2I8+1O03tI+37RM2i40m2v68lD6Y+fJWQ4u6dpt3EBCgF7TBgRcWcSfcQREbFT96nq9Nee05FlVW0Va/kVkvJWV4ZVggYj2+ad6toIBuF7U5KhtoTkOwHKD423M8msa+oErsRsdv7efNbsIqEPbEg3MbeYmLwbgEyMX59Sla6zbllhEgiRIkRIPke4+aXZa0tTfZoyYtioVZM4gcKPYUjcNPtJi65lVgCXY/6V2h67WoSJyn9Lp7B0913vFbylRbt47ODEkn+P2j5qrp5t+ovqhjbkZhIyjzE+aUWnNKygNkgfJSFJJGBkHMRzsCIO29ZOaYdc37WsBbGM3/gLemcW+cqV8LkxtyEyOAYjKJ2yjzEVPKYiYAgT48xx7k13S6J3yKicFLtuBAEAnc78jYb1odP0T3CLQIAMvDEKsheZPxWT3ta25xmT+fzpK6FFhKr0dswzANCjcrOxbtWTBAEnzzuK9VqL9s2Lbae4wa0VZrZL9naEYoT+XIjxPcfG1YmjtNBUMwD4hhJAaD25DyAYieK+g/hRLeJFxLdpbam0zBSfXZ5xRyFiO0ySeSPc1zfrnRDomDMSIjWZ3x57LpNaWtkrJ0GmtKjs6tJk2e8CV2Adl3x5mCfO01v/AIc6x9CPbt9oK5Bdh4X1DxE7yN9vmqOtaDJ7R+u46JCjGFByIE/GQ3/7t6tW3hdKeiBJQoE7oK7Agx3iSdveK5zj1t+6eozF8R9tp0gzYQdjhNACo2Deb/q35sLr1FrTXVBu3cBmy28FAUMuMgpEwfk+x+KlaVnttcCgWwRH5n2TYt5MGNh/rVWhT94pHqqqhHCtuSM5YLwAJJP6/pTl7UZyRahbkW15nEE+Jjwf6Uu4suTxnMxHPods5jmvLpjtfEC1oxMa3iCrtJZW8FbFUylwySD7TA8SK01t+xMCf9dzMVVo+9QWXhoGwlQAOPYGP5016kCfJqIY1syYF+wA7xrYanMwAeZWqOc6PbKst2+dufFc9GAF9v8AZq21dq6QRXTofTUKtOGm+MACJmNs8W0AwlC4grMVTPwDJg+xmlNYSwYCSDiAsjgAkwI8771o3FkyNjMfy3/lS1+TK4gqGG7MYERO/PI/nXOFM9JaTadj5aWtczb1TNN33A9vnfZY2qVAo9VmRJCsPpKZA9qeRbg777wPFZa3gE9bB1bJQrcs+MQ2/uYGQ5+eK9J1Upg4uD6vqEyQDsMAdpkEg7cVjNcY25ZhgLZsrauhco2CXAD+ckr7iKu6GiL50kazESM348rrq/TVOpknca29hqd7WBKp1Fv0ov8A1kKZQgAnKXORHkzufsPvXpdFZdmPqBiQW2kiTMp87eaybmocILpQKpuLaZYbAqMgzXPzZE/5BAAHmKzOr6kLcJsnK0SqKyyATAMCSd+asKTnCC78bC079jfXMJ5lBxt1QbiRixx7zm+pwq+rN6Vw4sVI2yDYmCN9/kGKx9K9sqyIjG9mGW7uEtKCv7xzyqAySStbOv19xhc1Ny2bllALYF4QSSFMLCkGGB/Q+9eR119rYQI2J9PvKODn6kMyllG6xj2sTEGnaLTUhhzbB2Em2TloIiL5te1SoS3n9+mnb9qwQl66WtHUhMw2BLW2O8v6gA2gFgY3+Kw+pXFEKjK4IV8gIYSu6HgbfHmmEN0ZoLhTLL1LZYrOAyIaYE7EAc7R53W12hKG3ureqoZArglcjAD7bN8U/T6W1PudpYbxqZtocWIuSbAc+q5xCzHaq7rT7cAbADjbwNz88mrbyFSVOxBIP6VQ1Pthcuoq2rtcau1dJnKstpWsGsegqi24vhyWeewrvAAnnjx4O9Y63KtS7WVRnVFzYzb97jhNUXtC1RZACnJTlJgHdYMd22xPI+KcVwSNz4AyMwAIj7D+lYa361bmot//AAq4XAZ+oRztMY+Jgj5+KweCCMnPz+N10qNYaL03QXdfVNphMC2R27ydsQdzMHjiN+au9S6LeZLYMxzUmFLqY3WdyB5jzXnemOMGcXQLgZVWyQwNzKRkHBAGPO5H/nRbo18ZCC7W2KXQkt6bBiMchs089sxO9JPpta+SQJjS5/HAHtldGlXBPzj9r2fT9TZsqhJVrg7yGSSHCwLEkbRK7Ef2qVnXAMGB79y2+XBIxeePA2niszpc20uA3Lq3iMmUgMGKkx3HdCFZtzVen1iqjW8QzsVxgjtMbEH6SDI81zfBmbkk58yZ0jp1yZEYwmGtkku+D2EX55jA91ae1db1ciFUMcQ+P2Bfbdo2G1N2eqW4lAz+kgIAIwVROzMBseftHxXmrPXIs6ZmXID92cyB6lsZ4ELJII3AJHj5mtOyPUR1thbK5NbuIwcPiQGJDCVZicgRxBH3pcNLcYBPsYxxpzBzMovoCIeD04zaJg833gZuZsvQ9PclY/MxydZOw4OGwaBt55M0/bIMwZPjHEE7HwNp8Vn6WwltEZWuFYgyRkJgSS3AlBsD5qdvU3WuysPalQSVxZIJyEGN+CfgCtAzQ/1sIkyIBjW+0meTUb1ucWmw3trjvsJwMlaFp1ExJYbt7jYHz9xUi7GCB7n+UxSdncsokMGYBt95gmZ4MRzXYUqoFwLPBDbssDIxtvJ3+1UBdfpsBGIEkEEwTnc30sbrE0xPw7/O0zhMSdiIJ3lR9jt96T1epFoSd+AUy4GQlj4J3qpbgJa0pJLTDbbcCYDTH/mlrnTFULcuXTjkDOO52kHyAJBO/iqMBNh2N+wPrreNmrenSaHfcfKDJ9PPlVvft3r3pyJYNBYZESIgKfhZHngxB3l1gm7p3RMSwtgkKwLgoDKlffkwu/8AdF+nsj3CLnpo7IEYkbs0SVEGd95G0VzTelpmIJa6zB3LJjDFWhbb8T8zyWrZtToM7+p3J21Bsngxv2lhnpggf/Rv7ETnSFhjWNeRbL5W7KLm65mbhyObgkSd94M7jasPrf4jfUBFeAEBAAA8xO/ngV6bFb+tZXR7TsmKoqKwYhe4gkkLtkNhtE1i9TewrXUa2Xt/umkLiyrKksm0ANIAJ5yB801TcCRaZEiMbefvaY2XRY5nUD03gHtNjBwZ3m8eSVslrGkum44NrVqFCK4zBRxuVIOIxz//ACK85o9I1y56SoCHXEjFcoHdlJ4bYSfNaeu6aWCurgWQrXEyeVADkm2kzDzJjyZNc6ppn1d8XrTNbV39EPcgCRbDQuPmMtvkb77bGq0SJ0JJIP2kQBby30WboEk6n+gNbwI/lYX/AAO9eLlFEKzJ9ScoJI59hMiRWFrLgZiQqqNtlmNgBO++8T+ta1xPSN5LoRsWNsyTkrTHqIOTEHY+9Yl1q6P07nEkzItEWyJ3M2jICQrkKhqg443/AE9qk1VtTgXMqFCpM9wEAned4/KIB3Pzt80VBqKm6UJXBUxUKvtWiak2V6ckrq1s6PQZsNwURVLle077n6uWBMTxC/akraqtdOr9qXf1O/x+fNL8rpUmtbdy3NJZsqrlw+ZA9HHHGQ3dn5+niPPNaHS+sPYM2WKkgA8EH5jjY8VmfhvVWiblu+GZGUsoDBQGUGCSSPBMDfng1rJprbsvoW3CsFAmTLEDIAnneaQrFvU6lUHrHSR5nvkaFdSgQ+wwVr6XT3r6tfFp7rZHNpGKwA0hBBBChdzIpnTqxNgG0M/ULZmXN3N53Qfc8czWx0xGTJLSYqCd8YuSViCTOwPj4o1WluLg4uML5IVYDTiVI2J2Bkxt7zXKNdrj0wAItfQj2GDGBjsyD90GOPQ5yI30AwJgjStfh61Ze4jupV3WFZNoYAgJB7WkMPsBxT1/Q2tOroSqqZKh3aAWIXIkcD2B+JNZGmdr7Mlxy7C0CuZAYYmRJHPP3+9JaPq1pUwvWmcEgQTOW5DYnlfj7Vi67yGySCOexiYsBtgZS3h1TYuJIiQIE8jGxmR+Ctb9ta6npoxtnYsxJk4/4hIG+/EExB8TA0X60ot2Ue3dT1IJPcFEbuyNvKSfJOzb1k6Lqgt2osvg5YJbtm33YMZFy5J7jBCgmJO2/h99GyOLaO0iy6iILMXxLNDSeYgLwP1NWLg0dQ1Nh+Rg5j2ss3tp9UPECSRocXOMTEZwb2vraVUYlUEkAMygYgDfA9pjKIA38E1KzdVnt2zdAdSHUWT2MsbZE7kEBuPc1jekGCq2oVQltcHwGRDduBI5AGPEfXTfTgtpQxBVmOJNwQVuqjA7BSFHaIMfnHNWpuB6SNYHpI4O5vhLVKENcZJOltYO+kXIAJH+JvdcfqllXuE2ohsclgEsGftWN5JQjIbbVHrGoZkRbQd2BbJUQ5KIAPIkmYED7+KydP04WC7s9sgh0UouZyzRTCngsMhA2xyMRNaev1Dae28hrjubhdj2SpaQrAjtBXOMdxjUFrYAntOf1PnqNrJk0qbajfDl17SbG0a7bSMi2qvTVaclO6611YAaG9RSDjiAAIEyCON68tcvsGiEVGbEzw+TgkMw3UeQRED3rX6R1OSzGyBcaMFtiZXcjtQeAILSOV2Fc6lrNMbt20bd8XbihSotpyskgRJHgyPA3NWNpc68DvgeQ0PYnS0XpA0nlhaSLagxqYiAAOrOhGATKR/4fea7eTEXfTtkq5IzGU4tbOIOP1SDJ35O0+Pvaq9attZ9DsLG5JDMyqfpYcGIAKsYmPavSWeq6dSl24br3lUybncoMEKAsjIT8+CfArzGo6lf9OFKqhYqyW9meY7Ty2OMKscARWtFhP8A0GcGwkTcXJPFu0C63a14JBFrcXFt/PAzjen8V9Nuaf02N7K1dHqLjlhLbv6YZjkB/m2nJT5rMu6hUYJfW4GXcwQIkgrt4hZO3kgeKuv3D+0Il+1eNpZC2A7MyKQSESTI3g+OKy+q6tbrPcwZcsRbiMQFABy23MAHbya6NITDNImRGpgYN7SSbzAMkysC9zWwT8+Z5VL6pRcLBQwloFwZTMiWHk7z96QvmQoCqIB3HLSSZbfnx42FRumrup6xLrFxaW0TAxtiEACxxzkTvTrWw4QPOdsfk/IXPqvmUg1VNVyQeTAg+J3jYc+TAnxNUGmQufUKiaKKKlLK0QK7658VTXBUQrh5GFcGpnSXFB7xIgj7fNJg1fauEEEcj7H+tVcJEJim+DKa08gwRB+ed969f09LqW7dwyEJPpnLiCCcRO28GvN9N6kgv+rqE9VWnIQPKlZVTtIOMe0U30y+pBlmkRgIkHffIztA9qTrtc6xG2k5kECIxqdl1vo6rWlfXfwz1Vlt+oYgNDExLEid/fmjq+p9XHcKrN6eR4HB3PtvXleg6g4upbBHWCSsy0SiDcRkSBPG9F68ttmS7cZLysuAQZRwcjtvsZ58VwHfThtR0G8yAL7CYzab6RFl0PDpiqamvz8Hv7rSOkW5cuxd/wANZLtB34Jj/L/Or7PTRL3Cs7AyGyAO5Ld28k47fevH2dZBdmIJBB7sg31fVHESADJ2mvcaTrgKn92y23tm42KgDEfmWed/b4q31IqUhYyMbaDFwb5thWe58fbf22n1/pJaLpVxyBZLXHIVx/8AWgBBxuz2ngQp23p7VIxserfuEkM2D2mDvuzvklsmbMnY4kQqwV9s/Raz0Ld18myAHq2j9JViVQEgjFjJM7x5EGo6NRcW5cXRMT6ZFrcBCoYqzEAjJg0iAZj+NTPVOonP25gb9OLHUQJ2VKjiHzNgRBx5SSBBtxF7r1ej1ls2FkC5jAa4bU25nl2AAJjcn3EUhd6mReWytzFUBe691UVnZZkjIHIcEb8E81kaS5gli211oIBcG2JUMcgZM90zuNwN9pitq+CwDWnW4lyR9PdbhY4IgDu+/P3GT29HUNDMnTIG2Y0ti2qz8JrCdQZicT/65yYsMcJHRax84tEtas5XC6loubmMy0YgHcn2mluqdU1V91tXZKvdDhVxBXdkEMY2gNzO2JkzXb+kY6VUS22eV0s+LACIIGYMEYydxtz81ndaDuGN9WQK9tPUQTZhZXIGT3sQ2/BkEitmsDHWiD66Qc3uTtGAtgGipMCQSL576ZN9NsWWr17WfvL1tLLOLShbTW2g2yqybzlCQW2JjbjxWT1X1Eu6Vr+odfUsqytmvqIMSSHYAGcyYmSQYmZhTq+v0pVEW5ca4Y9R8FCwqRbVVBEgbSWBMjnxWJ1PXPdc5EOJkHEAkLtzE7gTvv5NM0qMtgCAQdIz3nzBjSQqsbAbwNe0TcmJN8CdRdPa29IRlAUPsoDZMSvaWM9yyT9PH3p3T6l4C2bK5Kry0Q5/zbnn225I24rD0+oytXEz72uJimAhpgSbh+iPkjj5rd/DGgutL2TDqMg4+pdiDifEgkGrVWtDD16E5nXGc2Mag+yuXdTTi2/pf1Xl+qXM2zycs31FvB4EMNyMQPA9qzLlokqgMy+KwDDScQ6zHPHjjevQ6zQqXxZxb2O5BIkDYQPJjmsHqF1yq23Ji3kqg/lkyR/GnqLphrfljHeO9kn9S0gld1SWLd+8lw3LqqGRGHacwAAWBPCmR+grFJp3QX1t3Vd7Yuqp3RjAbYiDt+v6UpfcFmIGIJJCjhQTwPgcUzSYWm8mwvpOLCbbmBF+Fyqrv2qWNQY1bbUFgCwUHliDA+8An+AqmmEjUKKKKKlZIooooQug1MGq66DULRjk1ZQsQBySB/GvRaXpt1C6oVcgEXMcWWBi3a/njeIIiN685a2rb6L+JbmnDqn5lKnYcGlfqG1HD7IPB8oM8Z/YXU+lewO+8wm+rfia9eCrdxLIAgYABiqjtVo2IG548mkrWtGcsGcf92LH5neD5qnU61WB9PtyRDeDACXUiRbiTHB39jVeqshPTi4HzRXMAjEme0zyRHIrNgbEQRM77X7cXv7LYVosML1mm6k63Lept2QLJd7NtS+Vw8NFyDkxAYQYiQPPPbrM924zqFVJdgWiFY/kX80Sdv7mvL6IoXl3NsQSCqkmQJVRvI381aBkA73B3T5ycEcBl5APvxS7vpmtdIsYjDt53g2nGLcBM0qsBaVy4C/7oAgRbBAMXDuM4P0k7HGt2/qrwIsoipcLWyFD9yP6fpsQeBkNyOACa8m7wFXuUwS0ntJklSvt2wPvW0nWLS2lPoq98gfvS5NxGViczK/Ue2NzsP0Odai4hoDerS8HsSSYItyTaLWW4qr1X4fa8ty4tyGe2hJDjOFQfUG9lWPuNvtsdO17WLeSQ4e2bjE7Yxs0ePIHzXiber1GouOxOBO10k4qsmD6h8CRx/KkX19xRhm0NGCKQyscgd1nYGSeNztHNKf8Y1DciftkDGPW2RxncXd0uEGLxIjb++1uF6fqHW8S91LhDshDKyghs5V48AARvzSlzqWqi5Zu2vUL2kuooCsuK8McGgDGTPIisbq2suenZs3WLOgZfSKYm1MYy/5gRvR1Xply3YttcUT6vphkYEhQCAptqIZ5BOWRPANXFOkGta6BMgb2NosLWE7iInKrUeDFvmm3wro1ul/Z7qtbc35AtknZRG5mYEN4jf3pO/YJsJdlSolGjEMpyMBhy0iYO/FX6/Q4W7b3LqvdZcBZKln7SoVHluyB2ysERHzSfX76k27aT+6QoyZF1QzkxRvIJLExt/ZqkWucPDJgkmciBYxJtM5FtzchZGofn6XOjh2uLbRSwuEKw2ExuQGOwMH+da7fiv02urbQWgzt2iNhMBRGwA345msTp5stYvBxea9sbK2yMBt3u45MADjwN6U1nVrt2wlt2QpahV7VD8ECSBkwA2/QVo6gKlQ9QEWz6zrOwsMZOmP/ACC2/wCcJzq3UVfFgdjsyAywjkkx53I9p81mPcB4mPE+3ikiTE7xxPjccT9p2pnqKvbYW2uC5iq4lWLKAwyAUn7002mGkMB39PhCWf8AUlxkqVq6ELE20fJGSHE4zHev/UPH3rLemfUqm4K0Y0BxOpSVV0iyoY0UGit0kSiiiihQiiiihCKAaKKEKedSBqqug1ELVr1ehkxTmr11y4EW42QtKLaDbtUeNufvXH6qx09uxggFtzcDhe8kzsT5G/8AIe1VazSvbbG4pViA0H2YSD/CsAAXfeACCYwTGJHcZ7ppr7W4+eqY0d9kDsrKJXAgwSQ8g4gj458SKa1Gv9VLNsWrNv01K5quLXJM5XWJ3I4pdtQ2odQ5QOSq+o3aFVVgBo7QABMxNVWwgbvJYB1BwiGUE5wxOxgCNvPiqQLkt+7Nr8ZtN5zHMBbNqLT6X1AWLguYLddIwVwHtGVIOazvAbaOCPioWb6BQSASrGV/zhvbbtAj3PPilNU6Pec2pRGJK+oRIET3Ebe/8RSy3B7eNvj5+f8AWoDA4SQQTH+vyODfMLYVYuvYfhfSNqCbYj0wc3UGGjgBSRz9/bxSF24o1A9JihyRke6VBQ7NJx7eaVsIyYhLqsXt5H03IxBBJRztuANxSeq1QZ2bHkQAWJx2AmTueODSzaRe9zgftIx+SQcyRtiyZNb7RKbua4tde5dd3ubkOpH1j6WMjdRHA+KXvalnZnYksTkW+SZkx+tQ0ltCru9wDDGEmGuSYIQweOaos6jFpxVvhhI4jimWsaCegYgcaWH9WxqCFj4q0Oq6wXXzNoWziuyycue9ixJJM8z4pA3TzluZncz8yfma49xlEZAhlUmCDxuAfYj2rt7VgoqBFUCCx3LM2/dJ4EEbDbarU6fS0NaLfrzusnVZ1WmDpmDvbuvp2Sz9LEk3XMhlUg7AiB+vGxrKvo1pwJGQggqQR7il2eY42EbD+vud+agTU06PTNyRzB98nzJ4hYuqypm6Yxk4zMTtMRMcTBO/zVTNXCagTW4CWc9SLUBj7bVCuzUwsC9DVyiihVJRRRRUqEUUUUIRRRRQhFFFFCEA1PL/AH/KoUVEK4eQrA1SyqoNXQaiFq2ondI9sE+orMMWC4kCGjtJ24B8VZp+oMlq7aAUi5hJKgsMTIxPjzWfNdyqhptOePYyOy1FWE3ZfaoFt/fz/wC/iqkegXSJgkSIMHkex+KmFY1LBW3buTFoAkkwogCTwB4FQyqrKjKphV8RWFv9+9RJqE1yamFQ1FItUSa4TUalZGopE1yiipWZMoooooUIooooQiiiihCIoinNPYZ2CKJZtgJiT7fc8ferRobuCuLblG4YKSN2KASBsSwgDk7e4rXwuVXqWdFEVrP0m+Mf3FzuBIARiQFOJkRIgxz7j3FW2ehX2T1MQilgi+oyoXMK0IHILbMp25kRNHh8o6liRRFbGo6JqUYq2nvSLhtbW3ILgkYKYhm2Owqb9C1CxnbKSpaXBAEG4uDSO15tXIU79tR4fKOpYkURTFFT4XKOpL1ymaKPC5R1JeuzV9FHhco61QDRNX0UeFyp8QqiaJq+ijwuUeIUvXKZoo8LlR1JeKIpiiaPC5R1JeKIpiiaPC5R1JeKIpiaKPC5R1JeKIpjIUZCp8LlHUl4opgGio8LlHUpW7hUhlMMpDKfYgyD/EVuN+JnmRaRYMIBwqnAG2dsiIQbgruSd9owaK1VVqWOrKqqgs9qMrJLnIFGZ0yIUZANcuyIEhhxiDTej/E72zdZU77syTcf091x7rIIVyNypPBM7wKwKKIQvUH8ZvLEae2C4a2/dc3tO9y41sQRicrr943AjzJOf1TrnrWLWn9JVSxl6MMSUDu7OpJHcDknPHpiOSKx6KiAhFFFFSoRRRRQhFFFFCEUUUUIRRRRQhFFFFCEUz0/WtaYsoUkqV7hIHBDD/qVlVh8ilqKELa/4/vP7LpomY9MAcMBsP8AuP8ABfbeX/8AREqFOnsMAzMoKbLJY4qJgKMiI5Pk1h0UQpWve63lhOnsjBWUQu0NJiJ8EmPbf3mpXOvSGA09hZEAqgDId+9W5Dbj+ArGoohC9Av4puAz6a8k/U0gm5cuSD7g3CN5BEggya6PxXd820PzuPyBNwDDSJkEeREQK89RUQEJjX6o3bjXCAC0bAk8KFG5JJMASTyZopeipUL/2Q==";
//     bgImageElement.src = backImgPath;
// }, 1000);




